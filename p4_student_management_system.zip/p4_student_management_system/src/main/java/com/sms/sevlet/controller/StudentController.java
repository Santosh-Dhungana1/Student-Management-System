package com.sms.sevlet.controller;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.servlet.annotation.WebServlet;

import com.sms.sevlet.model.Student;


@WebServlet(loadOnStartup = 1)
public class StudentController {
	static EntityManagerFactory createEntityManagerFactory = Persistence.createEntityManagerFactory("sms");
	static EntityManager entityManager = createEntityManagerFactory.createEntityManager();
	static EntityTransaction entityTransaction = entityManager.getTransaction();
	
	public Student findStudent(int student_id) {
		return entityManager.find(Student.class, student_id);
	}
	
	public void updateStudent(int student_id,double student_contact,String student_address,String student_password) {
		Student student = entityManager.find(Student.class, student_id);
		if (student!=null) {
			
			entityTransaction.begin();
			entityManager.merge(student);
			entityTransaction.commit();
		}
		
	}

}
