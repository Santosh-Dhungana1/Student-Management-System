package com.sms.sevlet.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sms.sevlet.controller.AdminController;
import com.sms.sevlet.controller.StudentController;
import com.sms.sevlet.model.Admin;
import com.sms.sevlet.model.Student;

@WebServlet(value = "/Login")
public class Login extends HttpServlet {
	AdminController adminTable = new AdminController();
	StudentController studentTable = new StudentController();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username = req.getParameter("username");
		String password = req.getParameter("password");

		PrintWriter printWriter = resp.getWriter();

		AdminController adminController = new AdminController();
		Admin admin = adminController.findAdmin(1);
		if (username.equals(admin.getEmail()) && password.equals(admin.getPassword())) {
//			RequestDispatcher requestDispatcher = req.getRequestDispatcher("AdminDashboard.html");
//			requestDispatcher.forward(req, resp);
		} else {
			List<Student> students = admin.getStudents();
			for (Student student : students) {
				if (username.equals(student.getEmail()) && password.equals(student.getPassword())) {
					req.setAttribute("id", student.getId());
					req.setAttribute("name", student.getName());
					req.setAttribute("address", student.getAddress());//
					req.setAttribute("contact", student.getContact());//
					req.setAttribute("branch", student.getBranch());
					req.setAttribute("email", student.getEmail());
					req.setAttribute("gender", student.getGender());
					req.setAttribute("password", student.getPassword());//
					
					RequestDispatcher requestDispatcher = req.getRequestDispatcher("StudentDashboard.html");
					requestDispatcher.forward(req, resp);
					break;
				} else {
					printWriter.print("<html><body>");
					printWriter.print("<h1>Username / Password Invalid !</h1>");
					printWriter.print("</body></html>");
			resp.sendRedirect("Login.html");
//					RequestDispatcher requestDispatcher = req.getRequestDispatcher("Login.html");
//					requestDispatcher.include(req, resp);

				}	
			}

		}

	}
}
